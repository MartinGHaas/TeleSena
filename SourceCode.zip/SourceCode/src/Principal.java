import java.util.Scanner;
public class Principal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        ControleTeleSena c = new ControleTeleSena();

        System.out.println("\t[MENU]");
        System.out.println("* digite a opção desejada:");
        System.out.println("1 - Modo Rápido");
        System.out.println("2 - Modo Apresentação");

        for(int tentativas = 0; tentativas < 4; tentativas++) {
            int opcao = scanner.nextInt();

            if(opcao == 1) {
                modoRapido(c);
                break;
            } else if(opcao == 2) {
                modoApresentacao(c);
                break;
            } else if(tentativas != 3) {
                System.out.println("Ops! Parece que esta opção não existe! Tente novamente: ");
            }
        }
    }

    public static void modoRapido(ControleTeleSena c) {
        System.out.println("\t[NUMEROS SORTEADOS]");

        System.out.print("| ");
        ArrayHelp.imprimeSemDefault(c.getNumerosSorteados());
        System.out.print("|\n\n");

        System.out.println(c.financeiro());

        System.out.println("\n\t[GANHADORES]");
        System.out.println("Quantidade de Ganhadores: " + c.qtdGanhadores());
        ArrayHelp.imprimeSemDefault(c.getGanhadores());
    }

    public static void modoApresentacao(ControleTeleSena c) {

    }

}
